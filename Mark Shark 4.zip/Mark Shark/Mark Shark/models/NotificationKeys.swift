//
//  NotificationKeys.swift
//  Mark Shark
//
//  Created by Jason R. French on 12/16/24.
//

import Foundation

let lotNotificationKey = "edu.monmouth.csse337.s1338331.Mark-Shark.lots"
let spotNotificationKey = "edu.monmouth.csse337.s1338331.Mark-Shark.spots"


