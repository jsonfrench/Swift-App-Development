//
//  Calc_SwiftUIApp.swift
//  Calc-SwiftUI
//
//  Created by RamanLakshmanan on 11/21/23.
//

import SwiftUI

@main
struct Calc_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
