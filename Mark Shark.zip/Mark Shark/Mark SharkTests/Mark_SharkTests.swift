//
//  Mark_SharkTests.swift
//  Mark SharkTests
//
//  Created by Jason R. French on 10/15/24.
//

import Testing
@testable import Mark_Shark

struct Mark_SharkTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
